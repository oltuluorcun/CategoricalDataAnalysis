inst_pack_func <- function(list.of.packages){
  new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
  if(length(new.packages)) install.packages(new.packages)
  lapply(list.of.packages,function(x){library(x,character.only=TRUE)})
}

list.of.packages <- c("corrplot","ggplot2","reshape2", "gpairs", 
                      "GGally","gridExtra","fpp2","tidyverse",
                      "waffle","vcd","ROCR")
inst_pack_func(list.of.packages)

##############################

data <- readxl::read_excel("mt_1_data_set.xlsx")
str(data)

data <- data %>%
  mutate_if(is.character, as.factor) %>%
  mutate(EnvironmentSatisfaction = as.factor(EnvironmentSatisfaction))

summary(data)

###############################


####Correlation####
M <- cor(data %>%
           select_if(is.numeric))
corrplot(M, type = "upper", tl.pos = "d")
corrplot(M, add = TRUE, type = "lower", col = "Black", method = "number",
         diag = FALSE, tl.pos = "n", cl.pos = "n")

########  RQ1      ###########
# Percentage of Attrition based on Gender
Attr_gender <- ggplot(data, aes(x = Attrition)) + 
  geom_bar(aes(fill = Gender), position = 'fill') +
  labs(title="Percentage of Attrition based on Gender",
       y="percentage")
Attr_gender
#ggsave("RQ1.png")

table(data$Gender,data$Attrition)

chisq.test(
  table(subset(data, select = c(Attrition, Gender)))
)

######### RQ2 ##############

## Research question2 - Does the mean age for Attrition group and non-Attrition group differ? 
RQ2 <- ggplot(data, aes(y = Age, x = Attrition, fill=Attrition)) +
  geom_boxplot() +
  labs(title = "Attrition Based on Gender and Age")
RQ2
#ggsave("RQ2.png")

age_yes <- t(subset(data, select = Age, subset = Attrition == "Yes"))
age_no <- (subset(data, select = Age, subset = Attrition == "No"))

test_age <- t.test(age_yes,age_no)

cat("T-Test\n", file = "ttest_age.txt", append = TRUE)
capture.output(test_age, file = "ttest_age.txt", append = TRUE)

########  RQ3    ###########

RQ3 <- ggplot(data, aes(y = HourlyRate, x = JobRole)) +
  geom_boxplot() +
  labs(title = "Attrition Based on Rate and Business Travel")
RQ3
#ggsave("RQ3.png")

summary(aov(HourlyRate~JobRole, data = data))

########  RQ4    ###########
# Is there a correlation between Hourly Rate and Environment Satisfaction? 

RQ4 <- ggplot(data, aes(y = HourlyRate, x = EnvironmentSatisfaction, fill=Attrition)) +
  geom_boxplot() +
  labs(title = "Attrition Based on Rate and Environment Satisfaction")
RQ4
#ggsave("RQ4.png")

summary(aov(HourlyRate~EnvironmentSatisfaction, data = data))


########  RQ5    ###########

# Education Field for Attrition Group
Attr_EF <- ggplot(data, aes(x = Attrition)) + 
  geom_bar(aes(fill = EducationField), position = 'fill') +
  labs(title="Percentage of Attrition based on Gender",
       y="percentage")
Attr_EF
ggsave("RQ5.png")



## Waffle chart Education Field for Attrition Group
EF <- subset(data, select = EducationField, subset = Attrition == "Yes")
sum_EF <- as.numeric(table(EF))
names(sum_EF) <- as.character(levels(data$EducationField))

waffle(sum_EF, rows = 6, size=0.6,
       title="Education Field for Attrition Group",
       xlab="1 square = 1 person")
#ggsave("RQ5.png")

EF <- subset(data, select = EducationField, subset = Attrition == "No")
sum_EF <- as.numeric(table(EF))
names(sum_EF) <- as.character(levels(data$EducationField))

waffle(sum_EF, rows = 24, size=0.6,
       title="Education Field for Attrition Group",
       xlab="1 square = 1 person")


#############################

#### Univariate ####

## 1.1: Contingency table analyses  

cont_data <- data %>% select_if(is.factor)

for(i in 2:ncol(cont_data)){
  
  tbl <- table(cont_data[,c(i,1)])
  indep_test <- chisq.test(tbl)
  hypothesis <- ifelse(indep_test$p.value < 0.05, 
                       paste("Reject null hypothesis, Attrition and", names(cont_data)[i], "are independent"),
                       paste("Can not reject null hypothesis, Attrition and", names(cont_data)[i], "are not independent"))
  assign(
    paste("outputs_for_",names(cont_data)[i],sep=""),
    list(tbl, indep_test, pvalue=indep_test$p.value, hypothesis)
  )
  
}

## 1.2: Simple Log Reg

logreg_data <- data.frame(Attrition = data$Attrition, data %>% select_if(is.numeric))

for(i in 2:ncol(logreg_data)){
  
  f <- as.formula(paste("Attrition","~", 
                        paste(names(logreg_data)[i])))

  fit <- glm(formula = f,
             data = logreg_data, 
             family=binomial(link='logit'))
  
  coefs <- coef(fit)
  
  pval <- as.numeric(summary(fit)$coefficients[,4][2])
  
  hypothesis <- ifelse(pval < 0.05, 
                       paste("Reject null hypothesis,", names(logreg_data)[i], "is significant"), 
                       paste("Can not reject H0,", names(logreg_data)[i], "is not significant"))
  
  log_odds <- round(coefs[2],3)
  odds <- round(exp(coefs[2]),3)
  
  comments <- paste("one unit increase in", names(logreg_data)[i],
                    ifelse(coefs[2] > 0, "increases", "reduces"),
                    "the log odds by", log_odds,
                    "one unit increase in", names(logreg_data)[i], 
                    ifelse(coefs[2] > 0, "increases", "reduces"), 
                    "odds by", odds)
  assign(
    paste("outputs_for_",names(logreg_data)[i],sep=""),
    list(f, summary(fit), coefs, hypothesis,pval, log_odds, odds, comments)
  )
}

#### 2.	Multivariate analysis (Multiple logistic regression): ####
data.yedek <- data

#data prep
data$Attrition <- factor(data$Attrition, levels = c("No","Yes"), labels = 0:1)

set.seed(1)
index <- sample(nrow(data), size = floor(0.25 * nrow(data)),replace = FALSE)
test <- data[index,]
train <- data[-index,]

# all variables
fit1 <- glm(Attrition ~ ., data = data, 
            family = binomial(link='logit'))
summary(fit1)

AIC_model1 <- summary(fit1)$aic

threshold <- seq(0.1,0.9,0.02)
acc <- numeric()
for(i in 1:length(threshold)){
  log_pred <- predict(fit1,newdata = test,type='response')
  log_pred2 <- factor(ifelse(log_pred <= threshold[i],0,1), levels = 0:1)
  acc[i] <- as.numeric(caret::confusionMatrix(log_pred2,test$Attrition)$overall[1])
}
plot(acc~threshold, type = "b")

best_acc_threshold <- threshold[which.max(acc)]

log_pred <- predict(fit1,newdata = test,type='response')
log_pred2 <- factor(ifelse(log_pred <= best_acc_threshold,0,1), levels = 0:1)
caret::confusionMatrix(log_pred2,test$Attrition)

res <- predict(fit1, train, type = "response")
ROCRPred <- prediction(res, train$Attrition)
ROCRPerf <- performance(ROCRPred,"tpr","fpr")
plot(ROCRPerf, colorize = FALSE,
     print.cutoffs.at = seq(0.1, by = 0.1))

## Reduced model

f <- as.formula(paste("Attrition","~",
                      paste("Age","BusinessTravel",
                            "DailyRate","DistanceFromHome",
                            "EnvironmentSatisfaction",
                            "JobRole",sep = " + ")))

fit2 <- glm(f, data, family = 'binomial')
summary(fit2)

AIC_model2 <- summary(fit2)$aic

log_pred <- predict(fit2,newdata=test,type='response')
log_pred2 <- factor(ifelse(log_pred <= 0.4,0,1))
caret::confusionMatrix(log_pred2,test$Attrition)

res <- predict(fit2, train, type = "response")
ROCRPred <- prediction(res, train$Attrition)
ROCRPerf <- performance(ROCRPred,"tpr","fpr")
plot(ROCRPerf, colorize = FALSE,
     print.cutoffs.at = seq(0.1, by = 0.1))


## Reduced model 2

f <- as.formula(paste("Attrition","~",
                      paste("poly(Age,2)","BusinessTravel",
                            "poly(DailyRate,2)","poly(DistanceFromHome,2)",
                            "EnvironmentSatisfaction",
                            "JobRole",
                            sep = " + ")))

fit3 <- glm(f, data, family = 'binomial')
summary(fit3)

AIC_model3 <- summary(fit3)$aic


log_pred <- predict(fit3,newdata=test,type='response')
log_pred2 <- factor(ifelse(log_pred <= 0.4,0,1))
caret::confusionMatrix(log_pred2,test$Attrition)

res <- predict(fit3, train, type = "response")
ROCRPred <- prediction(res, train$Attrition)
ROCRPerf <- performance(ROCRPred,"tpr","fpr")
plot(ROCRPerf, colorize = FALSE,
     print.cutoffs.at = seq(0.1, by = 0.1))


















