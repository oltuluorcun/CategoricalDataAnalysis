### Midterm2 ### 
# http://library.lol/main/39A1D98940A8A5895461159C662F7838

#### packages
inst_pack_func <- function(list.of.packages){
  new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
  if(length(new.packages)) install.packages(new.packages)
  lapply(list.of.packages,function(x){library(x,character.only=TRUE)})
}
list.of.packages <- c("dplyr","ggplot2","tidyverse", "lme4","caret")
inst_pack_func(list.of.packages)

#### Read data 
data <- read.table("data.txt",header = TRUE)
data <- data %>%
  mutate(Farm = factor(Farm),
         Sex = factor(Sex),
         Disease = ifelse(Disease > 0, 1,0),
         Length = Length - mean(Length))
str(data)
summary(data)
anyNA(data)

## Explanatory data analysis
## Contingency tables:
## sex v disease
table(data$Sex, data$Disease)
#table(data$Sex, data$Disease)/rowSums(table(data$Sex, data$Disease))
# chi-square test
chisq.test(
  table(data$Sex, data$Disease)
)
## farm v disease
table(data$Disease, data$Farm)
# chi-square test
chisq.test(
  table(data$Disease, data$Farm)
)
## RQ1
ML <- ggplot(data, aes(x = Sex, y = Length, fill = Sex))+
  geom_boxplot()+
  geom_jitter(position=position_jitter(0.05)) +
  coord_flip()+
  labs(title="Distribution of Length based on Sex")
ML
#ggsave("ML.png")
## RQ2
SD <- ggplot(data, aes(x = Sex)) + 
  geom_bar(aes(fill = Disease), position = 'fill') +
  labs(title="Percentage of Disease based on Sex",
       y="percentage")
SD 
#ggsave("SD.png")
## RQ3 
LD <- ggplot(data, aes(y = Length, x = Disease,fill = Disease)) +
  geom_boxplot() +
  geom_jitter(position=position_jitter(0.05)) +
  coord_flip()+
  labs(title="Distribution of Length based on Disease")
LD
#ggsave("LD.png")
## RQ4
FD <- ggplot(data, aes(x = Farm)) + 
  geom_bar(aes(fill = Disease), position = 'fill') +
  labs(title="Percentage of Disease based on Farm",
       y="percentage")
FD
#ggsave("FD.png")

### GLM ###

## part a
fit1 <- glm(Disease ~ Farm + Sex + Length + Sex * Length, family = binomial, data = data)
summary(fit1)
## Part b
drop1(fit1, test="Chi")
## part c
jpeg("plot1.jpg")
index <- sort(data$Length,index.return=TRUE)$ix
farm.name <- levels(data$Farm)
par(mfrow=c(1,2))
for(j in 1:2){
  for(i in 1:length(farm.name)){
    
    if(i == 1){
      # female - male ayir 
      plot(data$Length, data$Disease, 
           main = paste(c("Female","Male"), "Data")[j],
           ylab = "Probability of presence of Disease",
           xlab = "Length")
    }
    
    x <- data %>% 
      mutate(Farm = farm.name[i],
             Sex = as.character(j),# 1 denotes female
             Length = Length)

      out <- predict(fit1, x, type = "response")
      lines(x$Length[index], out[index],
            col = paste(c("Red", "Blue"))[j])
  
  }
}
dev.off()

### GLMM ###
## Part A:
fit2 <- glmer(Disease ~ Length + Sex + Length*Sex + (1|Farm), 
              data = data, family = binomial, nAGQ=1)
summary(fit2)

## Part C:

par(mfrow = c(1,2))

# sex = 1 -> female

female <- 0.938969 + 0.038964 * data$Length  
female_prob <- exp(female) / (1 + exp(female))
index <- sort(data$Length,index.return=TRUE)$ix
plot(data$Length, data$Disease, col = "Red",
     ylab = "Probability of presence of Disease",
     xlab = "Length",
     main = "Female")
lines(data$Length[index],female_prob[index], col = "Red")
female_upper <- exp(female+1.96*1.546)/(1+exp(female+1.96*1.546)) 
female_lower <- exp(female-1.96*1.546)/(1+exp(female-1.96*1.546))
lines(data$Length[index], female_upper[index], lty = 2, col = "Red")
lines(data$Length[index], female_lower[index], lty = 2, col = "Red")

# sex = 2 -> male
male <- (0.938969 + 0.624487) + (0.038964 + 0.035859) * data$Length  
male_prob <- exp(male) / (1 + exp(male))
index <- sort(data$Length,index.return=TRUE)$ix
plot(data$Length, data$Disease, col = "Blue" ,
     ylab = "Probability of presence of Disease",
     xlab = "Length",
     main = "Male")
lines(data$Length[index],male_prob[index], col = "Blue")
male_upper <- exp(male+1.96*1.546)/(1+exp(male+1.96*1.546)) 
male_lower <- exp(male-1.96*1.546)/(1+exp(male-1.96*1.546))
lines(data$Length[index], male_upper[index], lty = 2, col = "Blue")
lines(data$Length[index], male_lower[index], lty = 2, col = "Blue")

##################

log_pred <- predict(fit1,type='response')
log_pred2 <- factor(ifelse(log_pred <= 0.5,0,1))
caret::confusionMatrix(log_pred2,factor(data$Disease))

log_pred <- predict(fit2,type='response')
log_pred2 <- factor(ifelse(log_pred <= 0.5,0,1))
caret::confusionMatrix(log_pred2,factor(data$Disease))
