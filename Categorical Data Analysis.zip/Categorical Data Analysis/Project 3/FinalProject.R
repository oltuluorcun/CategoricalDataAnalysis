inst_pack_func <- function(list.of.packages){
  new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
  if(length(new.packages)) install.packages(new.packages)
  lapply(list.of.packages,function(x){library(x,character.only=TRUE)})
}

list.of.packages <- c("ggplot2","dplyr","lsr","corrplot","PerformanceAnalytics","waffle",
                      "psych","gridExtra","ggpubr","FSelectorRcpp","MASS")
inst_pack_func(list.of.packages)


#### Data Prep. ####

heart <- read.csv("heart.csv")
head(heart)
names(heart) <- c("age", names(heart)[2:ncol(heart)])
head(heart)
str(heart)
anyNA(heart)

#colnames

colnames(heart) <- c("age", "sex", "chestpain", "restingbp", "chol","fastingbs",
                     "restingECG", "maxheartrate", "exinducedang", "STbyex", "slope", 
                     "majorvessel", "thal", "disease")


heart$sex <- factor(heart$sex)
heart$chestpain <- factor(heart$chestpain)
heart$fastingbs <- factor(heart$fastingbs)
heart$restingECG <- factor(heart$restingECG)
heart$exinducedang <- factor(heart$exinducedang)
heart$slope <- factor(heart$slope)
heart$majorvessel <- factor(heart$majorvessel)
heart$thal <- factor(heart$thal)
heart$disease <- factor(heart$disease)

str(heart)

#### EDA ####

# summary 

summary(heart)

# Correlation Matrix 

cor2 = function(df){
  
  stopifnot(inherits(df, "data.frame"))
  stopifnot(sapply(df, class) %in% c("integer"
                                     , "numeric"
                                     , "factor"
                                     , "character"))
  
  cor_fun <- function(pos_1, pos_2){
    
    # both are numeric
    if(class(df[[pos_1]]) %in% c("integer", "numeric") &&
       class(df[[pos_2]]) %in% c("integer", "numeric")){
      r <- stats::cor(df[[pos_1]]
                      , df[[pos_2]]
                      , use = "pairwise.complete.obs"
      )
    }
    
    # one is numeric and other is a factor/character
    if(class(df[[pos_1]]) %in% c("integer", "numeric") &&
       class(df[[pos_2]]) %in% c("factor", "character")){
      r <- sqrt(
        summary(
          stats::lm(df[[pos_1]] ~ as.factor(df[[pos_2]])))[["r.squared"]])
    }
    
    if(class(df[[pos_2]]) %in% c("integer", "numeric") &&
       class(df[[pos_1]]) %in% c("factor", "character")){
      r <- sqrt(
        summary(
          stats::lm(df[[pos_2]] ~ as.factor(df[[pos_1]])))[["r.squared"]])
    }
    
    # both are factor/character
    if(class(df[[pos_1]]) %in% c("factor", "character") &&
       class(df[[pos_2]]) %in% c("factor", "character")){
      r <- lsr::cramersV(df[[pos_1]], df[[pos_2]], simulate.p.value = TRUE)
    }
    
    return(r)
  } 
  
  cor_fun <- Vectorize(cor_fun)
  
  # now compute corr matrix
  corrmat <- outer(1:ncol(df)
                   , 1:ncol(df)
                   , function(x, y) cor_fun(x, y)
  )
  
  rownames(corrmat) <- colnames(df)
  colnames(corrmat) <- colnames(df)
  
  return(corrmat)
}

cor2(heart)

heart.numeric <- heart %>% select_if(is.numeric)

M <- cor(heart.numeric)
corrplot(M, type = "upper", tl.pos = "d")
corrplot(M, add = TRUE, type = "lower", col = "Black", method = "number",
         diag = FALSE, tl.pos = "n", cl.pos = "n")

chart.Correlation(heart.numeric)

#plot
pairs.panels(heart.numeric, 
             method = "spearman", 
             hist.col = "#00AFBB", density = TRUE, 
             ellipses = TRUE )


#### Waffle Chart ####
# Sex vs disease 

ST <- subset(heart, select = sex, subset = disease == "1")
sum_ST <- as.numeric(table(ST))
names(sum_ST) <- as.character(levels(heart$sex))

waffle(sum_ST, rows = 6, size=0.6,
       title="Education Field for Attrition Group",
       xlab="1 square = 1 person")


#### Research Questions ####

names(heart[,sapply(heart, is.factor)])

#### RQ1 #### 
# chestpain vs disease

table(heart$chestpain, heart$disease)
chisq.test(table(heart$chestpain, heart$disease))

RQ1 <- ggplot(data = heart, aes(x = disease)) + 
  geom_bar(aes(fill = chestpain),  position = 'fill') +  
  labs(title="Percentage of Heart Attack Risk Based on Chest Pain Levels", y = "Percentage")
RQ1 

#### RQ2 #### 

# Sex vs chol vs disease

RQ2 <- ggplot(data = heart, aes(x = disease, y = chol, fill = sex)) + 
  geom_boxplot() +  
  labs(title="Distribution of Cholesterol Based on Heart Attack Risk and Sex", y = "Serum Chol")
RQ2

########################

#### RQ3 #### 


# chestpain vs maxheartrate

RQ3 <- ggplot(data = heart, aes(x = disease, y = maxheartrate, fill = chestpain)) + 
  geom_boxplot() +  
  labs(title="Distribution of Maximum Heart Rate Based on Heart Attack Risk and Chest Pain Levels", y = "max heart rate")
RQ3

#### RQ4 #### 
#age vs disease

RQ4 <- ggplot(data = heart, aes(x = disease, y = age)) + 
  geom_violin(
    aes(fill = age), trim = FALSE,
    position = position_dodge(0.9) 
  ) + 
  geom_boxplot(fill = "Red", width = 0.15,
               position = position_dodge(0.9))+
  labs(title="Distribution of Age Based on Heart Attack Risk", y = "Age")
RQ4

#### RQ5 ####
#fastingbs vs restingbp vs disease

RQ5 <- ggplot(data = heart, aes(x = disease, y = restingbs, fill = fastingbs)) + 
  geom_boxplot() +  
  labs(title="Distribution of Resting Blood Pressure Based on Heart Attack Risk and fastingbs", y = "Resting Blood Pressure")
RQ5
#?test eklenebilir
t.test()

#### RQ6 ####
#sex vs age vs target

RQ6 <- ggplot(data = heart, aes(x = disease, y = maxheartrate, fill = chestpain)) + 
  geom_boxplot() +  
  labs(title="Distribution of Age Based on Heart Attack Risk and Sex", y = "maxheartrate")
ggsave("RQ6.png",RQ6)
#di?erinin yann?na ekle

#### RQ7 ####
#exinducedang(binary) vs thal(categoric) vs STbyex(cont.)

RQ7 <- ggplot(data = heart, aes(x = disease, y = chol, fill = restingbp)) + 
  labs(y = "restingbp")
ggsave("RQ7.png",RQ7)
#thal 0'? ??kar

#### RQ8 ####
#sex(categoric) vs vs disease(binary)
table(heart$sex, heart$disease)

RQ8 <- ggplot(data = heart, aes(x = sex)) + 
  geom_bar(aes(fill = disease),  position = 'fill') +  
  labs(title="Percentage of Heart Attack Risk Based on Sex", y = "Percentage")
RQ8 
chisq.test(table(heart$sex, heart$disease)) 

#### RQ9 ####
#slope(cat.) vs disease(binary) vs maxheartrate(cont)
RQ9 <- ggplot(data = heart, aes(x = disease, y = age, fill = sex)) + 
  geom_boxplot() +  
  labs(title="Distribution of Age Based on Heart Attack Risk and Sex", y = "Age")
ggsave("RQ9.png",RQ9)

RQ10 <- ggplot(data = heart, aes(x = disease, y = age, fill = majorvessel)) + 
  geom_boxplot() +  
  labs(title="Distribution of Age Based on Heart Attack Risk and majorvessel", y = "Age")
ggsave("RQ10.png",RQ10)


RQ11 <- ggplot(data = heart, aes(x = disease, y = maxheartrate, fill = slope)) + 
  geom_boxplot() +  
  labs(title="Distribution of maxheartrate Based on Heart Attack Risk and slope", y = "maxheartrate")
ggsave("RQ11.png",RQ11)

################################################

p <- paste("RQ",1:9,sep="")
for(i in 1:9){
  ggsave(filename = paste(p[i],".png",sep=""), get(p[i]),
         width = 8.57 , height = 5.33, units = "in",device='png')
  while (!is.null(dev.list()))  dev.off()
}
i=8
ggsave(filename = paste(p[i],".png",sep=""), get(p[i]),
       width = 8.57 , height = 5.33, units = "in",device='png')
################################################


heart.frac <- dplyr::sample_frac(heart, 1)
a<-ggplot(heart.frac, aes(chestpain, disease)) +
  geom_jitter(aes(color = chestpain), size = 0.3)+
  ggtitle("chestpain vs target")+
  ggpubr::color_palette("jco")+
  ggpubr::theme_pubclean()

b<-ggplot(heart.frac, aes(fastingbs, disease)) +
  geom_jitter(aes(color = fastingbs), size = 0.3)+
  ggtitle("fastingbs vs target")+
  ggpubr::color_palette("jco")+
  ggpubr::theme_pubclean()


c<-ggplot(heart.frac, aes(restingECG, disease)) +
  geom_jitter(aes(color = restingECG), size = 0.3)+
  ggtitle("restingECG vs target")+
  ggpubr::color_palette("jco")+
  ggpubr::theme_pubclean()



d<-ggplot(heart.frac, aes(exinducedang, disease)) +
  geom_jitter(aes(color = exinducedang), size = 0.3)+
  ggtitle("exinducedang vs target")+
  ggpubr::color_palette("jco")+
  ggpubr::theme_pubclean()

e<-ggplot(heart.frac, aes(slope, disease)) +
  geom_jitter(aes(color = slope), size = 0.3)+
  ggtitle("slope vs target")+
  ggpubr::color_palette("jco")+
  ggpubr::theme_pubclean()


f<-ggplot(heart.frac, aes(majorvessel, disease)) +
  geom_jitter(aes(color = majorvessel), size = 0.3)+
  ggtitle("majorvessel vs target")+
  ggpubr::color_palette("jco")+
  ggpubr::theme_pubclean()


g<-ggplot(heart.frac, aes(thal, disease)) +
  geom_jitter(aes(color = thal), size = 0.3)+
  ggtitle("thal vs target")+
  ggpubr::color_palette("jco")+
  ggpubr::theme_pubclean()

figure<- ggarrange(a,b,d,c,e,f,g ,ncol = 3, nrow = 3)
figure


chis <- lapply(heart[,c(3,6,7,9,11:13)], function(x) chisq.test(heart[,c(14)],x,simulate.p.value=TRUE))
do.call(rbind, chis)[,c(1,3)]

###########################################################################
heart.cat <- heart %>% select_if(is.factor)

cat.names <- names(heart.cat)[-9]
rq.names <- paste("RQ10.",1:length(cat.names),sep="")
for(i in 1:length(cat.names)){
  assign(x = rq.names[i],
         value = ggplot(data = data.frame(x = heart.cat[,i], y = heart.cat[,9]), aes(x=x)) + 
    geom_bar(aes(fill = heart.cat[,9]),  position = 'fill') +  
    labs(title=paste("Percentage of Heart Attack Risk Based on ", rq.names[i]), y = "Percentage"))
}

grid.arrange(RQ10.1,RQ10.2,RQ10.3,RQ10.4,RQ10.5,RQ10.6,RQ10.7,RQ10.8, nrow=3,ncol=3)

chis <- lapply(heart.cat[,-9], function(x) chisq.test(heart.cat[,9],x,simulate.p.value=TRUE))
chis.out <- do.call(rbind, chis)[,c(1,3)]
knitr::kable(chis.out)
###########################################################################


ggplot(aes(disease, chol, fill = thal),data = heart) +
  geom_col(position = "dodge") +
  theme_bw()+
  facet_wrap(~disease,scales = "free_x")+
  ggtitle("xoxoxox")


#thal: A blood disorder called thalassemia 0=normal...3=reversable defect


ggplot(aes(disease, chol, fill = majorvessel),data = heart) +
  geom_col(position = "dodge") +
  theme_bw()+
  facet_wrap(~disease,scales = "free_x")+
  scale_fill_brewer(palette="Dark2")+ggtitle("...")

#ca=number of major vessels (0-4) ; the more major vessels is a good thing, and therefore will reduce the probability of heart disease.

ggboxplot(
  heart, x = "disease", y = c("chol", "thal"), 
  merge = TRUE, palette = "jco"
)+ggtitle("...")

#maximum heart rate achieved =thal
# MANOVA test
man <- manova(cbind(chol, thal) ~ disease, data = heart)
summary(man)

summary.aov(man)


ggplot(aes(disease, chol, fill = fastingbs),data = heart) +
  geom_col(position = "dodge") +
  theme_bw()+
  facet_wrap(~disease,scales = "free_x")+
  scale_fill_brewer(palette="Dark2")+ggtitle("...")


################################################

#### Modeling #### 

#### Train test ####

heart[,sapply(heart, is.numeric)] <- scale(heart[,sapply(heart, is.numeric)])

set.seed(482)
index <- sample(1:nrow(heart), size = floor(nrow(heart) * 0.25), replace = F)
test <- heart[index,]
train <- heart[-index,]


#### Fit1 - Full Model ####
options(scipen=999) 
fit1 <- glm(disease ~ ., data = heart, family = binomial)
summary(fit1)

AIC_model1 <- summary(fit1)$aic

log_pred <- predict(fit1, newdata = test, type = 'response')
log_pred2 <- factor(ifelse(log_pred <= 0.5,0,1))
caret::confusionMatrix(log_pred2,test$disease)

accuracy_fit1 <- caret::confusionMatrix(log_pred2,test$disease)$overall[1]
sensSpec_fit1 <- caret::confusionMatrix(log_pred2,test$disease)$byClass[1:2]

#### Fit2 - Reduced Model ####

fit2 <- glm(disease ~ sex + chestpain + restingbp + majorvessel, data = train, family = binomial)
summary(fit2)

AIC_model2 <- summary(fit2)$aic

log_pred <- predict(fit2, newdata = test, type = 'response')
log_pred2 <- factor(ifelse(log_pred <= 0.5,0,1))
caret::confusionMatrix(log_pred2,test$disease)

accuracy_fit2 <- caret::confusionMatrix(log_pred2,test$disease)$overall[1]
sensSpec_fit2 <- caret::confusionMatrix(log_pred2,test$disease)$byClass[1:2]


#### Fit3 - Reduced Model ####
#### Information Gain ####

ig <-information_gain(disease~., data=heart, type="infogain", discIntegers = F)
class(ig)
barplot(ig$importance)
#grafikle?tir

fit3 <- glm(disease ~ maxheartrate + chol + chestpain + majorvessel + thal, data = heart, family = binomial)
summary(fit3)

AIC_model3 <- summary(fit3)$aic

log_pred <- predict(fit3, newdata = test, type = 'response')
log_pred3 <- factor(ifelse(log_pred <= 0.5,0,1))
caret::confusionMatrix(log_pred3,test$disease)

accuracy_fit3 <- caret::confusionMatrix(log_pred3,test$disease)$overall[1]
sensSpec_fit3 <- caret::confusionMatrix(log_pred3,test$disease)$byClass[1:2]

#### Fit4 - Reduced Model ####
#According to correlation

fit4 <- glm(disease ~ age + sex + exinducedang + STbyex + slope + maxheartrate + chestpain + majorvessel + thal, data = heart, family = binomial)
summary(fit4)

AIC_model4 <- summary(fit4)$aic

log_pred <- predict(fit4, newdata = test, type = 'response')
log_pred4 <- factor(ifelse(log_pred <= 0.5,0,1))
caret::confusionMatrix(log_pred4,test$disease)

accuracy_fit4 <- caret::confusionMatrix(log_pred4,test$disease)$overall[1]
sensSpec_fit4 <- caret::confusionMatrix(log_pred4,test$disease)$byClass[1:2]

#### Fit5 - Reduced Model ####
#According to high correlations

fit5 <- glm(disease ~ exinducedang + STbyex + maxheartrate + chestpain + majorvessel + thal, data = heart, family = binomial)
summary(fit5)

AIC_model5 <- summary(fit5)$aic

log_pred <- predict(fit5, newdata = test, type = 'response')
log_pred5 <- factor(ifelse(log_pred <= 0.5,0,1))
caret::confusionMatrix(log_pred5,test$disease)

accuracy_fit5 <- caret::confusionMatrix(log_pred5,test$disease)$overall[1]
sensSpec_fit5 <- caret::confusionMatrix(log_pred5,test$disease)$byClass[1:2]

#stepwise elimination

fit6 <- stepAIC(fit1)
summary(fit6)

AIC_model6 <- summary(fit6)$aic

log_pred <- predict(fit6, newdata = test, type = 'response')
log_pred6 <- factor(ifelse(log_pred <= 0.5,0,1))
caret::confusionMatrix(log_pred6,test$disease)

accuracy_fit6 <- caret::confusionMatrix(log_pred6,test$disease)$overall[1]
sensSpec_fit6 <- caret::confusionMatrix(log_pred6,test$disease)$byClass[1:2]

fit7 <- glm(disease ~ poly(age,3) + sex + exinducedang + poly(STbyex,3) + slope + 
              poly(maxheartrate,3) + chestpain + majorvessel + thal, data = heart, family = binomial)
summary(fit7)


###############################################

#### K-fold Cross Validation ####

set.seed(482)
shuffle <- sample(1:nrow(heart), replace = F, size = nrow(heart))
heart <- heart[shuffle,]

k <- 5
N <- nrow(heart)
subset.train <- list()
subset.test <- list()
for(j in 1:k){
  subset.train[[j]] <- setdiff(1:N, (ceiling((j-1)*N/k):((j * N) / k)))
  subset.test[[j]] <- (ceiling((j-1)*N/k):((j * N) / k))
}

f <- list(model1 = as.formula(paste("disease ~ .")),
          model2 = as.formula(paste("disease ~ sex + chestpain + restingbp + majorvessel")),
          model3 = as.formula(paste("disease ~ exinducedang + STbyex + maxheartrate + chestpain + majorvessel + thal")),
          model4 = as.formula(paste("disease ~ age + sex + exinducedang + STbyex + slope + 
                                    maxheartrate + chestpain + majorvessel + thal")),
          model5 = as.formula(paste("disease ~ poly(age,3) + sex + exinducedang + STbyex + slope + 
                                    poly(maxheartrate,3) + chestpain + majorvessel + thal")),
          model6 = as.formula(paste("disease ~ maxheartrate + chol + chestpain + majorvessel + thal")))

accuracy <- matrix(0, ncol = length(f)+1, nrow = k,
                   dimnames = list(c(paste("k=",1:k,sep ="")),
                                   c(paste("model",1:(length(f)+1),sep = ""))))

sens <- matrix(0, ncol = length(f)+1, nrow = k,
               dimnames = list(c(paste("k=",1:k,sep ="")),
                               c(paste("model",1:(length(f)+1),sep = ""))))

spec <- matrix(0, ncol = length(f)+1, nrow = k,
               dimnames = list(c(paste("k=",1:k,sep ="")),
                               c(paste("model",1:(length(f)+1),sep = ""))))

AIC_model <- matrix(0, ncol = length(f)+1, nrow = k,
                    dimnames = list(c(paste("k=",1:k,sep ="")),
                                    c(paste("model",1:(length(f)+1),sep = ""))))
for(j in 1:k){
  #folds
  for(i in 1:(length(f)+1)){
    #models
    train <- heart[subset.train[[j]],]
    test <- heart[subset.test[[j]],]
    
    if(i == length(f)+1){
      fit <- stepAIC(glm(disease ~ ., data = train, family = binomial),
                     trace = FALSE)
    }else{
      fit <- glm(f[[i]], data = train, family = binomial)
    }
    
    AIC_model[j,i] <- summary(fit)$aic
    
    log_pred <- predict(fit, newdata = test, type = 'response')
    log_pred2 <- factor(ifelse(log_pred <= 0.5,0,1))
    
    result <- caret::confusionMatrix(log_pred2,test$disease)
    accuracy[j,i] <- result$overall[1]
    sens[j,i] <- result$byClass[1]
    spec[j,i] <- result$byClass[2]
  }
  cat(j)
}

mean_AIC <- colMeans(AIC_model)
mean_accuracy <- colMeans(accuracy)
mean_sensitivity <- colMeans(sens)
mean_specificity <- colMeans(spec)

out <- rbind(mean_AIC,mean_accuracy,mean_sensitivity,mean_specificity)

titles <- paste("Mean",c("AIC","Accuracy","Sensitivity","Specificity"),"for Each Model")

out

#### hepsi icin
for(i in 1:nrow(out)){
  assign(x = paste("plot",i,sep=""),
         value = ggplot(data=data.frame(x=out[i,], y = paste("model",1:(length(f)+1))), aes(x=x,y=y)) +
           geom_bar(stat = "identity", fill = "Gold") +
           geom_text(aes(label = round(x,2)), vjust = 0, hjust = 2) +  
           labs(title=titles[i], y = "", x = ""))
}
ggsave("hepsi.png",grid.arrange(plot1, plot2, plot3, plot4, nrow=2,ncol=2),
       width = 8.57 , height = 5.33, units = "in",device='png')
dev.off()

#########################################################################################################


RQ3_anova <- aov(maxheartrate ~ disease + thal, data = heart)
summary(RQ3_anova)

RQ4_anova <- aov(chol ~ disease + majorvessel, data = heart)
summary(RQ4_anova)

RQ6_anova <- aov(maxheartrate ~ disease + chestpain, data = heart)
summary(RQ6_anova)

RQ7_anova <- aov(age ~ disease + sex, data = heart)
summary(RQ7_anova)

RQ8_anova <- aov(age ~ disease + majorvessel, data = heart)
summary(RQ8_anova)

RQ9_anova <- aov(maxheartrate ~ disease + slope, data = heart)
summary(RQ9_anova)



